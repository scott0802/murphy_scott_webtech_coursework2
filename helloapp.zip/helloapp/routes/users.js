const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');


const User = require('../models/User');


/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

//sign up and constraints
router.post('/signin', (req, res) => {
   const { name, email, password, password2} = req.body; 
    let errors = [];
    
    if(!name || !email || !password || !password2) {
     errors.push({msg: 'Please fill all fields.'});  
    }
    
    if(password !== password2) {
           errors.push({msg: 'Passwords are not identical.'});  
    }
    
    if(errors.length > 0){
       res.render('signin_page', {
           errors,
           name,
           email,
           password,
           password2
       });
    } else {
               const newUser = new User({
                   name,
                   email,
                   password
               }); 
        //save user to database
                console.log(newUser)
                
                newUser
                    .save();
            }
        });
    

module.exports = router;
