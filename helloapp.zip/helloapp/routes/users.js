var express = require('express');
var router = express.Router();
var bcrypt = require('bcryptjs');
var passport = require('passport');


var User = require('../models/User');


/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

//sign up and constraints
router.post('/signin', (req, res) => {
   var { name, email, password, password2} = req.body; 
    let errors = [];
    
    if(!name || !email || !password || !password2) {
     errors.push({msg: 'Please fill all fields.'});  
    }
    
    if(password !== password2) {
           errors.push({msg: 'Passwords are not identical.'});  
    }
    
    if(errors.length > 0){
       res.render('signin_page', {
           errors,
           name,
           email,
           password,
           password2
       });
    } else {
               var newUser = new User({
                   name,
                   email,
                   password
               }); 
        //save user to database
                console.log(newUser)
                
                newUser
                    .save();
            }
        });
    
router.post('/login', (req, res, login) => {
     passport.authenticate('local', {
    successRedirect: '/home',
    failureRedirect: '/login',
    failureFlash: true
  })(req, res, next);
});

module.exports = router;
