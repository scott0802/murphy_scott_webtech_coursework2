var express = require('express');
var router = express.Router();


/* GET all pages. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

    router.get('/caesar', function(req, res, next) {
  res.render('assessment_caesar_page', { title: 'Caesar' });
});

router.get('/morse', function(req, res, next) {
  res.render('assessment_morse_page', { title: 'Morse' });
});
router.get('/bacon', function(req, res, next) {
  res.render('assessment_bacon_page', { title: 'Bacon' });
});
router.get('/login', function(req, res, next) {
  res.render('login_page', { title: 'Log In' });
});

router.get('/signin', function(req, res, next) {
  res.render('signin_page', { title: 'Sign In' });
});


module.exports = router;
