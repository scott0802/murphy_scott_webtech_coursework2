//creating the dictionaries
var morCod = {" ":"/", "a":"._", "b":"_...", "c":"_._.", "d":"_..", "e":".", "f":".._.", "g":"__.", "h":"....", "i":"..", "j":".___", "k":"_._", "l":"._..","m":"__", "n":"_.", "o":"___", "p":".__.", "q":"__._", "r":"._.", "s":"...", "t":"_", "u":".._", "v":"..._", "w":".__", "x":"_.._", "y":"_.__", "z":"__..", "0":"_____", "1":".____", "2":"..___", "3":"...__", "4":"...._", "5":".....", "6":"_....", "7":"__...", "8":"___..", "9":"____."};

var eng = {"/":" ", "._":"a", "_...":"b", "_._.":"c", "_..":"d", ".":"e", ".._.":"f", "__.":"g", "....":"h", "..":"i", ".___":"j", "_._":"k", "._..":"l","__":"m", "_.":"n", "___":"o", ".__.":"p", "__._":"q", "._.":"r", "...":"s", "_":"t", ".._":"u", "..._":"v", ".__":"w", "_.._":"x", "_.__":"y", "z":"__..", "0":"_____", "1":".____", "2":"..___", "3":"...__", "4":"...._", "5":".....", "6":"_....", "7":"__...", "8":"___..", "9":"____."};


function encrypt() 
{
    //take text from message box and put it into a variavle and make lowercase
    var plain_text = document.getElementById("message").value.toLocaleLowerCase();
    var tempText = []; 
    
    //looping for every character
    for (var idx = 0; idx<plain_text.length; idx++)
    {
        //if the character is in the morse dictionary
        //put it into temporary var
        if (morCod[plain_text[idx]])
        {
            tempText.push(morCod[plain_text[idx]]);
        }
    }
    //display joined morse characters with space between characters and slash for space
      document.getElementById("output").value = tempText.join(" ");  
}

function decrypt()
{
     //take text from output box and put it into a variavle and make lowercase
    var plain_text = document.getElementById("output").value.split(" ");
    var tempText = []; 
    
    for (var idx = 0; idx<plain_text.length; idx++)
    {
        //if the character is in the english alphabet 
        //put it into temporary var
        if (eng[plain_text[idx]])
        {
            tempText.push(eng[plain_text[idx]]);
        }
    }
     //display joined morse characters with no space between characters
      document.getElementById("message").value = tempText.join("");  
    
}