//creating the dictionaries
var bacon = {"a":"aaaaa", "b":"aaaab", "c":"aaaba", "d":"aaabb", "e":"aabaa", "f":"aabab","g":"aabba","h":"aabbb", "i":"abaaa", "j":"abaab", "k":"ababa", "l":"ababb", "m":"abbaa", "n":"abbab", "o":"abbba", "p":"abbbb", "q":"baaaa", "r":"baaab", "s":"baaba", "t":"baabb", "u":"babaa", "v":"babab", "w":"babba", "x":"babbb", "y":"bbaaa", "z":"bbaab", " ":"/"};

var eng = {"aaaaa":"a", "aaaab":"b", "aaaba":"c", "aaabb":"d", "aabaa":"e", "aabab":"f", "aabba":"g", "aabbb":"h", "abaaa":"i", "abaab":"j", "ababa":"k", "ababb":"l", "abbaa":"m", "abbab":"n", "abbba":"o", "abbbb":"p", "baaaa":"q", "baaab":"r", "baaba":"s", "baabb":"t", "babaa":"u", "babab":"v", "babba":"w", "babbb":"x", "bbaaa":"y", "bbaab":"z", "/":" "};

var cypher_text = " ";

function encrypt() 
{
     //take text from message box and put it into a variavle and make lowercase
    var plain_text = document.getElementById("message").value.toLocaleLowerCase();
    var cypher_text = []; 
    
    for (var idx = 0; idx<plain_text.length; idx++)
    {
        //if the character is in the bacon dictionary
        //put it into temporary var
        if (bacon[plain_text[idx]])
        {
            cypher_text.push(bacon[plain_text[idx]]);
        }
    }
     //display joined bacon characters with space between characters and slash for space
      document.getElementById("output").value = cypher_text.join(" ");  
}

function decrypt()
{
    //take text from message box and put it into a variavle and split at a space 
    var plain_text = document.getElementById("output").value.split(" ");
     var cypher_text = []; 
    
    for (var idx = 0; idx<plain_text.length; idx++)
    {
        //if the character is in the bacon dictionary
        //put it into temporary var
        if (eng[plain_text[idx]])
        {
            cypher_text.push(eng[plain_text[idx]]);
        }
    }
    //display decrypted text
      document.getElementById("message").value = cypher_text.join("");  
    
}