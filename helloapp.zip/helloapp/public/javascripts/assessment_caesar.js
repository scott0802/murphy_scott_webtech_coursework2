//creating an alphabet varible for lower and upper case
var alphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
var alphabetCap = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];

//encrypt buttons function
function encrypt() {
    
    //create a variable based on the shift feature, the text to be encrypted and an empty variable to be filled
    var shiftNo = parseInt(document.getElementById("shift").value); 
    var plain_text = document.getElementById("message").value;
	var tempText = ['']; 

    //looping for every character
    for (var idx = 0; idx<plain_text.length; idx++)
    { 
        //the character 
        var input = alphabet.indexOf(plain_text[idx]); 
        var inputAlt = alphabetCap.indexOf(plain_text[idx]);
        
        //if something other than one of the letters is inserted pass it through
        //otherwise is lowercase create a variable that tells where to shift and another with the new valie then pushing it into the temp variable 
        //otherwise if uppercase repeat for the uppercase letters
        if(input == -1 && inputAlt == -1)
        { 
            tempText.push(plain_text[idx]);
        }
        else if (input != -1)
        {
            var coded = (input+shiftNo)%26; 
            var letter = alphabet[coded]; 
            tempText.push(letter);
            
        }
        else if (inputAlt != -1)
        {
            var codedAlt = (inputAlt+shiftNo)%26; 
            var letterAlt = alphabetCap[codedAlt];
            tempText.push(letterAlt);
        }
    } 
    //use the temp variable and join then insert into output box
    document.getElementById("output").value = tempText.join("");

}

//decrypt button function
function decrypt()
    {
        //create a variable based on the shift feature, the text to be decrypted and an empty variable to be filled
   var shiftNo = parseInt(document.getElementById("shift").value); 
    var plain_text = document.getElementById("output").value;
	var tempText = ['']; 
    
    
    for (var idx = 0; idx<plain_text.length; idx++)
    { 
        var input = alphabet.indexOf(plain_text[idx]); 
        var inputAlt = alphabetCap.indexOf(plain_text[idx]);
        
        
        //if something other than one of the letters is inserted pass it through
        //otherwise is lowercase create a variable that tells where to shift and another with the new valie then pushing it into the temp variable 
        //otherwise if uppercase repeat for the uppercase letters
        if(input == -1 && inputAlt == -1)
        { 
            tempText.push(plain_text[idx]);
        }
        else if (input != -1)
        {
            var coded = (input+26-shiftNo)%26; 
            var letter = alphabet[coded]; 
            tempText.push(letter);
            
        }
        else if (inputAlt != -1)
        {
            var codedAlt = (inputAlt+26-shiftNo)%26; 
            var letterAlt = alphabetCap[codedAlt];
            tempText.push(letterAlt);
        }
    } 
        //use the temp variable and join then insert into message box
    document.getElementById("message").value = tempText.join("");
    }

  