//connect mongo db
module.exports = {
    MongoURI:'mongodb+srv://scottM:<scottM>@cluster0-qha8k.mongodb.net/test?retryWrites=true'

}